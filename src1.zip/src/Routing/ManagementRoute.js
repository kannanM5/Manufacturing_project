// import {
//   DevicePrivateRoute,
//   EmployeePrivateRoute,
//   MachinePrivateRoute,
//   ShiftPrivateRoute,
//   WorkShedulePrivateRoute,
// } from "../Views/AuthScreens/PrivateRoute";

// export const managementRoute = [
//   {
//     path: "device",
//     element: <DevicePrivateRoute />,
//     children: [
//       {
//         index: true,
//         element: <DeviceManagement />,
//       },
//     ],
//   },
//   {
//     path: "machine",
//     element: <MachinePrivateRoute />,
//     children: [
//       {
//         index: true,
//         element: <MachineManagement />,
//       },
//       {
//         path: "macine_details_list",
//         element: <MachineDetailsList />,
//       },
//       {
//         path: "MachineScheduleDetails",
//         element: <ScheduleApp />,
//       },
//     ],
//   },
//   {
//     path: "employee_management",
//     element: <EmployeePrivateRoute />,
//     children: [
//       {
//         index: true,
//         element: <EmployeeManagement />,
//       },
//       {
//         path: "emp_details_list",
//         element: <EmployeeDetailsList />,
//       },
//     ],
//   },
//   {
//     path: "shift",
//     element: <ShiftPrivateRoute />,
//     children: [
//       {
//         index: true,
//         element: <Shift />,
//       },
//     ],
//   },
//   {
//     path: "work_shedule",
//     element: <WorkShedulePrivateRoute />,
//     children: [
//       {
//         index: true,
//         element: <WorkShedule />,
//       },
//     ],
//   },
// ];
