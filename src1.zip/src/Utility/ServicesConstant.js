// export const devicebaseUrl = "http://192.168.1.23:8003/";

// Development

export const baseUrl = "http://192.168.1.117:8001";
// export const SALT_KEY = "L4jkmn71iwelcv@1qaz!";

// Demo Server

// export const baseUrl = " http://cbe.themaestro.in:8021/root_mconnect/";
