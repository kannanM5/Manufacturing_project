import { Outlet } from "react-router-dom";

function ProfileLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}

export default ProfileLayout;
